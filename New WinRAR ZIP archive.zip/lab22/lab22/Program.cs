﻿using System;
using System.Collections.Generic;
using System.Linq;

class Gift
{
    private List<Sweet> sweets = new List<Sweet>();

    public void AddSweet(Sweet sweet)
    {
        sweets.Add(sweet);
    }

    public void RemoveSweet(Sweet sweet)
    {
        sweets.Remove(sweet);
    }

    public double GetTotalWeight()
    {
        double totalWeight = sweets.Sum(sweet => sweet.Weight); // вычисление общего веса конфет в подарке
        return totalWeight;
    }

    public double GetTotalPrice()
    {
        double totalPrice = sweets.Sum(sweet => sweet.Price); // вычисление общей стоимости конфет в подарке
        return totalPrice;
    }

    public Sweet GetMostExpensiveSweet()
    {
        Sweet mostExpensiveSweet = sweets.OrderByDescending(sweet => sweet.Price).First(); // поиск самой дорогой конфеты в подарке
        return mostExpensiveSweet;
    }
}

class Sweet
{
    public string Name { get; set; }
    public double Weight { get; set; }
    public double Price { get; set; }

    public Sweet(string name, double weight, double price) // конструктор класса Sweet
    {
        Name = name;
        Weight = weight;
        Price = price;
    }
}

class Program
{
    static void Main()
    {
        Gift gift = new Gift(); // создание объекта подарок

        Sweet sweet1 = new Sweet("Candy1", 0.1, 50); // создание объектов конфет
        Sweet sweet2 = new Sweet("Candy2", 0.2, 75);
        Sweet sweet3 = new Sweet("Candy3", 0.3, 100);

        gift.AddSweet(sweet1); // добавление конфет в подарок
        gift.AddSweet(sweet2);
        gift.AddSweet(sweet3);

        Console.WriteLine("Total weight: " + gift.GetTotalWeight() + " g"); // вывод общего веса конфет в подарке
        Console.WriteLine("Total price: " + gift.GetTotalPrice() + " $"); // вывод общей стоимости конфет в подарке
        Console.WriteLine("Most expensive sweet: " + gift.GetMostExpensiveSweet().Name); // вывод самой дорогой конфеты в подарке
    }
}